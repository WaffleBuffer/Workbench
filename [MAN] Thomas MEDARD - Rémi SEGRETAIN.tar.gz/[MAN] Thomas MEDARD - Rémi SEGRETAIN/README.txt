-Il faut être sur un environnement Linux.

-Les dossiers bin et obj sont présents pour la compilation (makefile).

-Le fichier benchmark (fichier bash) executent les tests pour l'ensemble des tris (l'executable doit exister dans bin).

-En sortie, les fichiers CSV seront générées à la racine de l'exécution (même dossier que benchmark).

-Pour compiler : "make"
-pour exécuter : "./benchmark" (le fichier doit avoir les permissions d'executions).
